/**
 * Datele fixe folosite la generarea facturilor
 */
public class Constante {
    public static final int NUMAR_MAXIM_PRODUSE = 10;
    
    public static final String[] DENUMIRI_CLIENTI = new String[] {
            "ALCOR CONSTRUCT SRL",
            "SC DOMINO COSTI SRL",
            "SC TRANSCRIPT SRL",
            "SIBLANY SRL",
            "INTERFLOOR SYSTEM SRL",
            "MERCURY  IMPEX  2000  SRL",
            "ALEXANDER SRL",
            "METAL INOX IMPORT EXPOSRT SRL",
            "EURIAL BROKER DE ASIGURARE SRL"
    };
    
    public static final String[] DENUMIRI_PRODUSE = new String[] {
            "Stafide 200g",
            "Seminte de pin 300g",
            "Bulion Topoloveana 190g",
            "Paine neagra Frontera",
            "Ceai verde Lipton"
    };
    
    public static double[] PRETURI_PRODUSE = new double[] {
            5.20,
            12.99,
            6.29,
            4.08,
            8.99
    };
}
