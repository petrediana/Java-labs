import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
class Factura {

    @Override
    public String toString() {
        var dateFormat = DateTimeFormatter.ofPattern("yyyy-MMM-dd");
        final StringBuilder sb = new StringBuilder();
        sb.append(String.format("%s, Client: %s%n",
                dateFormat.format(dataEmitere), denumireClient));
        for (var linie : linii) {
            sb.append(linie.toString() + System.lineSeparator());
        }
        return sb.toString();
    }

    static class Linie {

        @Override
        public String toString() {
            return String.format("%-25s %3d x %5.2f RON = %6.2f RON",
                    produs, cantitate, pret, getValoare());
        }
    }
}
