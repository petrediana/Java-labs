import java.io.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class Main {

    public static List<Factura> generareListaFacturi(int numarFacturi, LocalDate dataMinima) {
        Random rand = new Random();
        List<Factura> facturi = new ArrayList<>();

        int numarMaximZile = (int) ChronoUnit.DAYS.between(dataMinima, LocalDate.now());

        for (int indexFactura = 0; indexFactura < numarFacturi; indexFactura++) {
            // Obtinem o denumire de client random din lista DENUMIRI_CLIENTI
            var denumireClient = Constante.DENUMIRI_CLIENTI[rand.nextInt(Constante.DENUMIRI_CLIENTI.length)];

            // Obtinem o data random
            var data = dataMinima.plusDays(rand.nextInt(numarMaximZile));

            // Instantiem o noua factura pe baza: denumire client, data

            // Obtinem un numar de produse random pentru a le atasa facturii curente
            var numarProduse = 1 + rand.nextInt(Constante.NUMAR_MAXIM_PRODUSE - 1);

            for (int indexProdus = 0; indexProdus < numarProduse; indexProdus++) {
                // Obtinem un index random pentru produs

                // Selectam un produs din DENUMIRI_PRODUSE

                // Selectam un pret din PRETURI_PRODUSE

                // Generez o cantitate la intamplare

                // Adaugam in factura pe baza: produs, pret, cantitate
            }

            // Adaug factura curenta in lista de facturi
        }

        return facturi;
    }

    static void afisareFacturi(List<Factura> facturi) {
    }

    static void salvareFacturi(String caleFisier, List<Factura> facturi) throws IOException {
        if (new File(caleFisier).getParentFile() != null) {
            new File(caleFisier).getParentFile().mkdirs();
        }

        try (var fisier = new DataOutputStream(
                new BufferedOutputStream(
                        new FileOutputStream(caleFisier)))) {
            for (var factura : facturi) {
                // Scriem informatiile pentru factura si anume:
                // denumire client
                // an data emitere
                // luna data emitere
                // zi data emitere
                // numarul de linii

                // Folosim fisier.writeUTF(...) pentru string, fisier.writeInt(...) pentru int, fisier.writeDouble(...) pentru double etc

                // Pentru fiecare linie a facturii curente trebuie sa scriu proprietatile si anume

                // produs
                // pret
                // cantitate

            }
        }
    }

    static List<Factura> incarcareFacturi(String caleFisier) throws IOException {
        List<Factura> facturi = new ArrayList<>();

        try (var fisier = new DataInputStream(
                new BufferedInputStream(
                        new FileInputStream(caleFisier)))) {

            // Citim din fisier pana intalnesc exceptia EOFException -> am ajuns la sfarsitul fisierului
            while (true) {
                // Citesc datele pentru factura si anume:
                // denumireClient
                // an
                // luna
                // zi
                // numar de linii


                // Folosim fisier.readUTF() pentru string, fisier.readInt() pentru int, fisier.readDouble() pt double


                // Instantiez un nou obiect de tip factura folosind valorile citite anterior

                // Pentru data folosesc LocalDate.of(an, luna, zi)


                // Pentru fiecare linie a facturii citesc datele si anume:
                // denumire
                // pret
                // cantitate
                // Adaug linia citita in factura


                // Adaug factura curenta la lista de facturi
            }
        } catch (EOFException e) {
            // nu facem nimic
        }

        return facturi;
    }


    static void generareRaport(String caleRaport, List<Factura> facturi) throws IOException {
        class DateClient {
            public final String denumireClient;
            public int numarFacturi = 0;
            public double valoareTotala = 0;

            public DateClient(String denumireClient) {
                this.denumireClient = denumireClient;
            }

            public String toString() {
                return String.format("%-40s %3d facturi, TOTAL: %8.2f RON",
                        denumireClient, numarFacturi, valoareTotala);
            }
        }

        Map<String, DateClient> clienti = new HashMap<>();

        // Populez obiectul clienti cu datele despre facturi


        try (PrintWriter fisier = new PrintWriter(caleRaport)) {
            // Scriu datele - ma folosesc de fisier.println(...)
        }
    }

    public static void main(String[] args) throws IOException {
        final String caleFisier = "date\\facturi.dat";

        var facturi = generareListaFacturi(
                5,
                LocalDate.of(2020, 1, 1));

        System.out.println("Facturi generate:");
        afisareFacturi(facturi);

//        salvareFacturi(caleFisier, facturi);
//
//        System.out.println();
//        System.out.println("=============================================");
//        System.out.println();
//
//        var facturiIncarcate = incarcareFacturi(caleFisier);
//        System.out.println("Facturi incarcate:");
//        afisareFacturi(facturiIncarcate);
//
//        generareRaport("date\\raport.txt", facturi);
//        System.out.println("Raportul a fost generat.");
    }
}
