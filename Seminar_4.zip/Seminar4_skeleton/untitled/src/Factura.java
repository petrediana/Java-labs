import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
class Factura {

    private final String denumireClient;
    private final LocalDate dataEmitere;
    private final List<Linie> linii;

    public Factura(String denumireClient, LocalDate dataEmitere) {
        this.denumireClient = denumireClient;
        this.dataEmitere = dataEmitere;
        this.linii = new ArrayList<>();
    }

    public double getValoare() {
        double valoare = 0;

        for (Linie linie : linii) {
            valoare += linie.getValoare();
        }

        return valoare;
    }

    public void adaugaLinie(String produs, double pret, int cantitate) {
        linii.add(new Linie(produs, pret, cantitate));
    }

    public Linie getLinie(int index) {
        if (index >= linii.size()) {
            throw new ArrayIndexOutOfBoundsException("Index prea mare!");
        }

        return linii.get(index);
    }

    public int getNumarLinii() {
        return linii.size();
    }

    public String getDenumireClient() {
        return denumireClient;
    }

    public LocalDate getDataEmitere() {
        return dataEmitere;
    }

    @Override
    public String toString() {
        var dateFormat = DateTimeFormatter.ofPattern("yyyy-MMM-dd");
        final StringBuilder sb = new StringBuilder();
        sb.append(String.format("%s, Client: %s%n",
                dateFormat.format(dataEmitere), denumireClient));
        for (var linie : linii) {
            sb.append(linie.toString() + System.lineSeparator());
        }
        return sb.toString();
    }

    static class Linie {

        private final String produs;
        private final double pret;

        private final int cantitate;

        public Linie(String produs, double pret, int cantitate) {
            this.produs = produs;
            this.pret = pret;
            this.cantitate = cantitate;
        }

        public String getProdus() {
            return produs;
        }

        public double getPret() {
            return pret;
        }

        public int getCantitate() {
            return cantitate;
        }

        public double getValoare() {
            return pret * cantitate;
        }

        @Override
        public String toString() {
            return String.format("%-25s %3d x %5.2f RON = %6.2f RON",
                    produs, cantitate, pret, getValoare());
        }
    }
}
